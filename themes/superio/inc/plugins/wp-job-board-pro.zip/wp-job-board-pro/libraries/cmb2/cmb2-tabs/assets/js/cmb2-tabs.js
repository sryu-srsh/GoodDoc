(function ($) {
    $(document).ready(function () {
        // init jQuery UI Tabs
        setTimeout(function () {
            $( ".dtheme-cmb2-tabs" ).tabs();
        });
    });
})(jQuery);

jQuery.noConflict();